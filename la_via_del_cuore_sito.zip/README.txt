LA VIA DEL CUORE – SITO WEB

Questa cartella contiene:
- index.html: pagina principale del sito
- images/logo.jpg: logo fornito
- images/orari.jpg: planning corsi fornito

Il sito è responsive e pronto per essere pubblicato gratuitamente su servizi come GitHub Pages.
